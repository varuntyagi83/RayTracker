# Voltic Documentation Hub

<p align="center">
  <img src="https://img.shields.io/badge/Version-1.0-blue?style=for-the-badge" alt="Version">
  <img src="https://img.shields.io/badge/Status-Live-green?style=for-the-badge" alt="Status">
  <img src="https://img.shields.io/badge/License-MIT-purple?style=for-the-badge" alt="License">
</p>

<p align="center">
  <strong>Meta Advertising Intelligence & Creative Generation Platform</strong>
</p>

---

## 🌐 Live Demo

Visit the live documentation at: **[https://varuntyagi83.github.io/voltic-docs](https://varuntyagi83.github.io/voltic-docs)**

## 📁 Repository Structure

```
voltic-docs/
├── index.html      # Landing page with navigation to both docs
├── guide.html      # User Guide (comprehensive documentation)
├── pitch.html      # Pitch Deck (interactive product overview)
├── README.md       # This file
└── .nojekyll       # Tells GitHub Pages not to use Jekyll
```

## 📖 Documents

### User Guide (`guide.html`)
Comprehensive documentation covering:
- All platform features and workflows
- Step-by-step tutorials
- API reference and integrations
- Best practices and troubleshooting
- Keyboard shortcuts and glossary

### Pitch Deck (`pitch.html`)
Interactive product overview including:
- Animated hero with live statistics
- Feature tabs with detailed explanations
- Before/After AI transformation slider
- Competitor comparison table (vs Supermetrics, AdSpy, Foreplay, Motion)
- Customer testimonials carousel
- Interactive credit calculator
- Pricing cards
- FAQ accordion
- Dark/Light mode toggle

## 🚀 Deployment to GitHub Pages

### Option 1: Quick Setup (Recommended)

1. **Create a new repository** on GitHub named `voltic-docs`

2. **Clone and push:**
   ```bash
   git clone https://github.com/YOUR_USERNAME/voltic-docs.git
   cd voltic-docs
   # Copy all files from this folder
   git add .
   git commit -m "Initial commit: Voltic documentation"
   git push origin main
   ```

3. **Enable GitHub Pages:**
   - Go to repository **Settings** → **Pages**
   - Under "Source", select **Deploy from a branch**
   - Select **main** branch and **/ (root)** folder
   - Click **Save**

4. **Access your site** at `https://YOUR_USERNAME.github.io/voltic-docs`

### Option 2: Using GitHub CLI

```bash
# Create repo and push in one go
gh repo create voltic-docs --public --source=. --push

# Enable GitHub Pages
gh api repos/YOUR_USERNAME/voltic-docs/pages -X POST -f source='{"branch":"main","path":"/"}'
```

### Option 3: Fork This Repository

Simply fork this repo and enable GitHub Pages in your fork's settings.

## 🔧 Customization

### Update Calendly Link
Find and replace all instances of the demo booking link:
```
https://calendly.com/varun-tyagi83/30min
```

### Update Branding Colors
Edit the CSS variables in each HTML file:
```css
:root {
  --accent-blue: #6366f1;
  --accent-cyan: #22d3ee;
  --accent-magenta: #ec4899;
  --gradient-1: linear-gradient(135deg, #6366f1 0%, #8b5cf6 50%, #ec4899 100%);
}
```

### Add Your Own Video
In `pitch.html`, replace the YouTube embed placeholder:
```html
<div class="video-container" onclick="this.innerHTML='<iframe src=\'https://www.youtube.com/embed/YOUR_VIDEO_ID?autoplay=1\' ...
```

### Update Testimonials
Edit the testimonial cards in `pitch.html` with real customer quotes.

## 📱 Features

- ✅ Fully responsive (mobile, tablet, desktop)
- ✅ Dark/Light mode toggle
- ✅ Animated counters and transitions
- ✅ Interactive credit calculator
- ✅ Before/After comparison slider
- ✅ Smooth scroll navigation
- ✅ Reading progress bar
- ✅ Floating CTA button
- ✅ FAQ accordion
- ✅ No build step required (pure HTML/CSS/JS)

## 🛠 Tech Stack

- **HTML5** — Semantic markup
- **CSS3** — Custom properties, Grid, Flexbox, animations
- **Vanilla JavaScript** — No frameworks required
- **Google Fonts** — Outfit, Fira Code
- **GitHub Pages** — Free hosting

## 📄 License

MIT License — feel free to use and modify for your own projects.

---

<p align="center">
  <strong>Built with ❤️ for Voltic</strong><br>
  <a href="https://calendly.com/varun-tyagi83/30min">Book a Demo</a>
</p>
